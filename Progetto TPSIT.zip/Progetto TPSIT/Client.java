/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author Jacopo Crocetta
 */
public class Client {

    public static void main(String[] args) throws IOException {
        String hostName;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int portNumber = 5236;
        System.out.println("Qual' è il tuo nome? ");
        hostName = input.readLine();
        Socket socket;
        try {
            BufferedReader i = new BufferedReader(new InputStreamReader(System.in));
            socket = new Socket(hostName, portNumber);
            PrintWriter out = new PrintWriter(socket.getOutputStream());
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String fromServer = in.readLine();
            String fromUser;
            while (fromServer != null) {
                System.out.println("Server: " + fromServer);
                fromUser = i.readLine();
                if (fromUser != null) {
                    System.out.println("HostName: " + fromUser);
                    out.println(fromUser);
                } else if (fromUser.equalsIgnoreCase("Bye")) {
                    out.println("Bye.");
                    socket.close();
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }
}
