/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

/**
 *
 * @author Jacopo Crocetta
 */
import java.io.*;
import java.net.*;

/*
 *Al posto di far estendere la classe Thread ho preferito implementare l'interfaccia Runnable
 *in modo tale da avere carta bianca sulla codifica e l'implementazione del metodo run.
 */
public class Server {

    public static void main(String[] args) throws IOException {

        int portNumber = 5236;
        System.out.println("Waiting connection from user to port " + portNumber);
        ServerSocket ss = new ServerSocket(portNumber);
        while (true) {
            Socket conn = ss.accept();
            Task task = new Task(conn);
            Thread t = new Thread(task);
            t.start();
        }
    }
}

class Task implements Runnable {

    Socket conn;

    public Task(Socket conn) {
        this.conn = conn;
    }

    @Override
    public void run() {
        String input;
        String output;
        try {
            PrintWriter out = new PrintWriter(new OutputStreamWriter(conn.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            Protocol protocol = new Protocol();
            output = protocol.processInput("");
            out.println(output);
            while ((input = in.readLine()) != null) {
                output = protocol.processInput(input);
                out.println(output);
                if (output.equalsIgnoreCase("Bye.")) {
                    break;
                }
            }
            conn.shutdownInput();
            conn.shutdownOutput();
        } catch (IOException ex) {
            //System.out.println(ex.getMessage());
            System.out.println("Client disconneso");
        }
    }
}
