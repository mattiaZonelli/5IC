/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.util.LinkedList;

/**
 *
 * @author Jacopo Crocetta
 */
public class Protocol {
    
    private static final int PRESENTAZIONE = 0;
    private static final int DOMANDA = 1;
    private static final int RISPOSTA = 2;
    private static final int ANOTHER = 3;
    private int state = PRESENTAZIONE;
    private final String[] question = {"How are you?", "What's your favourite colour?", "What Do you Like?", "What Time is it?", "What is your favorite sport?", "How old are you", "What studies are you attending?"};
    private final String[] answer = {"I'm fine, thanks", "I really Like blue", "I'm a robot, i don'tknow", "Summer time", "My is football", "I do not age", "Progremming"};
    private final LinkedList<String> UpdateAnswer;
    private final LinkedList<String> UpdateQuestion;
    
    public Protocol() {
        UpdateAnswer = new LinkedList<>();
        UpdateQuestion = new LinkedList<>();
    }
    
    public String processInput(String theInput) {
        String theOutput = null;
        switch (state) {
            case PRESENTAZIONE:
                theOutput = "Hi, I'm Jacob, and I'm here to talk with you";
                state = DOMANDA;
                break;
            case DOMANDA:
                if (theInput.equalsIgnoreCase("Hi jacob") || theInput.equalsIgnoreCase("Hi")) {
                    theOutput = "Ask me something";
                    state = RISPOSTA;
                } else {
                    theOutput = "You're supposed to say \"Hi jacob\", you know";
                }
                break;
            case RISPOSTA:
                for (int i = 0; i < question.length; i++) {
                    if (question[i].equalsIgnoreCase(theInput)) {
                        theOutput = answer[i] + " Want another? (Y/N)";
                        state = RISPOSTA;
                    } else if (UpdateQuestion.get(i).equalsIgnoreCase(theInput)) {
                        theOutput = UpdateAnswer.get(i) + " Want another? (Y/N)";
                        state = RISPOSTA;
                    }
                }
                break;
            default:
                break;
        }
        if (state != ANOTHER) {
            int i = 0;
            while (i <= UpdateAnswer.size()) {
                if (theInput.equalsIgnoreCase(UpdateAnswer.get(i))) {
                    theOutput = UpdateAnswer.get(i);
                    break;
                }
                i++;
            }
            theOutput = "I'm not able to answer this question, I'm so sorry. Want to do an upload the answer and hypothetical question? (Y/N)";
            state=ANOTHER;
        } else if (state == ANOTHER) {
            if (theInput.equalsIgnoreCase("y")) {
                UpdateQuestion.add(theInput);
                UpdateAnswer.add(theInput);
                theOutput = "Ok, I updated answers and question";
                state = RISPOSTA;
                //In questo modo ho aggiunto l'apprendimento artificiale del protocollo
            }
        } else {
            theOutput = "Do you want to continue? (Y/N)";
            if (theInput.equalsIgnoreCase("y")) {
                state = DOMANDA;
            } else {
                state = PRESENTAZIONE;
            }
        }
        return theOutput;
    }
}
