package com.example.jacopo.quizzone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


/**
 * Created by JACOPO on 27/01/2017.
 */

public class MainActivity extends Activity {
    private Button quiz1;
    private Button quiz2;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activiy);
        quiz1=(Button)findViewById(R.id.button1);
        quiz1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this, QuizActivity1.class);
                startActivity(intent);
            }
        });
        quiz2=(Button)findViewById(R.id.button2);
        quiz2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this, QuizActivity1.class);
                startActivity(intent);
            }
        });
    }
}
