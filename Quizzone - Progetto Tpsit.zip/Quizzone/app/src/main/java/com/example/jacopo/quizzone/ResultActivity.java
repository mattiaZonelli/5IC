package com.example.jacopo.quizzone;

/**
 * Created by JACOPO on 24/01/2017.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class ResultActivity extends Activity {
    Button button_To_MainActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);//get rating bar object
        RatingBar bar = (RatingBar) findViewById(R.id.ratingBar1);//get text view
        TextView t = (TextView) findViewById(R.id.textResult);//get score
        Bundle b = getIntent().getExtras();
        final int score = b.getInt("score");
        //display score
        bar.setRating(score);
        switch (score) {
            case 1:
                t.setText("Non sai proprio nulla");
                break;
            case 2:
                t.setText("Sai proprio poco");
                break;
            case 3:
                t.setText("Ti andrà meglio la prossima volta");
                break;
            case 4:
                t.setText("Hmmmm.. Qualcuno sa molte cose");
                break;
            case 5:
                t.setText("Chi sei? Il mago dei quiz???");
                break;
        }
        //Ritorno all'attività principale
        button_To_MainActivity=(Button)findViewById(R.id.button1);
        button_To_MainActivity.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(ResultActivity.this, MainActivity.class);
                Context context=getApplicationContext();
                char text=(char) score;
                int duration=Toast.LENGTH_LONG;
                Toast toast=Toast.makeText(context,text,duration);//Andando nella schermata principale faccio un Toast che segna il mio punteggio
                startActivity(intent);
            }
        });
    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_result, menu);
        return true;
    }
*/
}
